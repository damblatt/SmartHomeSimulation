﻿namespace M320_SmartHome {
    public class Kueche : Zimmer {
        public Kueche() : base("Küche") {
        }
    }
}
